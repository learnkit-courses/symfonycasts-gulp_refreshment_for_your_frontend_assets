$(document).ready(function() {
    console.log('It\'s a Unix system, I know this');
    $('.navbar-static-bottom').prepend('<span class="navbar-text">Life finds a way</span>');
});
